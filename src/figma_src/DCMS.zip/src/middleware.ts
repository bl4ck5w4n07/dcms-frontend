import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Check if the request is for dashboard routes
  if (pathname.startsWith('/dashboard')) {
    // In a real application, you would check for a valid JWT token or session
    // For this demo, we'll check if there's a user in localStorage (handled client-side)
    // Since middleware runs on the server, we can't access localStorage directly
    // Instead, we'll let the client-side components handle authentication
    
    // For now, we'll allow all dashboard requests and let the client handle auth
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*']
};