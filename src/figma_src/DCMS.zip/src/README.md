# SmileCare Dental - Next.js Application

A comprehensive dental clinic management system built with Next.js, TypeScript, and Tailwind CSS.

## Features

- **Public Homepage**: Marketing page with booking form for anonymous users
- **Role-based Authentication**: Support for patients, staff, dentists, and admin users
- **Appointment Management**: Booking, viewing, and managing appointments
- **Patient Records**: Comprehensive patient management (admin/dentist only)
- **Walk-in Patients**: Quick registration for walk-in appointments (staff+)
- **Patient Profiles**: Self-service profile management for registered patients

## Tech Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **UI Components**: Custom components with shadcn/ui
- **Authentication**: Custom context-based auth system
- **Icons**: Lucide React

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm, yarn, or pnpm

### Installation

1. Install dependencies:
```bash
npm install
# or
yarn install
# or
pnpm install
```

2. Run the development server:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Demo Credentials

The application includes mock authentication with the following test accounts:

- **Admin**: admin@dentalclinic.com
- **Dentist**: dentist@dentalclinic.com  
- **Staff**: staff@dentalclinic.com
- **Patient**: patient@example.com
- **Password**: password123 (for all accounts)

## Project Structure

```
├── app/                    # Next.js App Router
│   ├── layout.tsx         # Root layout with AuthProvider
│   ├── page.tsx           # Homepage (public)
│   ├── login/page.tsx     # Login page
│   └── dashboard/         # Protected dashboard routes
├── components/            # React components
├── contexts/             # React contexts (Auth)
├── data/                 # Mock data
├── styles/               # Global CSS and Tailwind config
└── types/                # TypeScript type definitions
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## Key Features by Role

### Anonymous Users
- View marketing homepage
- Book appointments via contact form
- Sign up for account

### Patients  
- Book appointments
- View their appointment history
- Manage personal profile
- Update contact information

### Staff
- View all appointments
- Manage appointment status (confirm/cancel/complete)
- Add walk-in patients
- Book appointments for patients

### Dentists
- All staff permissions
- View patient records
- Full appointment management

### Admin
- All system permissions
- User management
- Full patient records access
- System configuration

## Authentication Flow

1. **Homepage**: Public marketing page with booking form
2. **Sign In/Sign Up**: Redirects to login page
3. **Login**: Authenticate and redirect to role-appropriate dashboard
4. **Dashboard**: Role-based navigation and features
5. **Logout**: Return to homepage

## Development Notes

- The application uses mock data for demonstration purposes
- Authentication is simulated (no real backend integration)
- All patient data is fictional for privacy
- The booking form sends demo requests (no real API calls)

## Deployment

The application is ready for deployment on platforms like Vercel, Netlify, or any Node.js hosting service.

For Vercel deployment:
```bash
npm run build
```

## License

This project is for demonstration purposes only.