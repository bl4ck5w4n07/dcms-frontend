'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar, Clock, User, Phone, Mail, MessageSquare, CheckCircle, XCircle, RotateCcw, Calendar as CalendarIcon } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Appointment {
  id: string;
  patientId?: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  reason: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  confirmedDate?: string;
  confirmedTime?: string;
  dentistId?: string;
  dentistName?: string;
  notes: Array<{
    id: string;
    content: string;
    authorId: string;
    authorName: string;
    authorRole: string;
    createdAt: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

interface Dentist {
  id: string;
  name: string;
  specialization: string;
  available: boolean;
}

export function AppointmentManager() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [dentists, setDentists] = useState<Dentist[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [noteDialog, setNoteDialog] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [confirmData, setConfirmData] = useState({
    date: '',
    time: '',
    dentistId: ''
  });

  useEffect(() => {
    fetchAppointments();
    fetchDentists();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await fetch('/api/appointments');
      const data = await response.json();
      
      if (data.appointments) {
        setAppointments(data.appointments);
      }
    } catch (error) {
      console.error('Error fetching appointments:', error);
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  const fetchDentists = async () => {
    try {
      const response = await fetch('/api/dentists');
      const data = await response.json();
      
      if (data.dentists) {
        setDentists(data.dentists);
      }
    } catch (error) {
      console.error('Error fetching dentists:', error);
    }
  };

  const confirmAppointment = async () => {
    if (!selectedAppointment || !confirmData.date || !confirmData.time || !confirmData.dentistId) {
      toast.error('Please fill in all confirmation details');
      return;
    }

    try {
      const response = await fetch(`/api/appointments/${selectedAppointment.id}/confirm`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(confirmData),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Appointment confirmed successfully');
        setConfirmDialog(false);
        setSelectedAppointment(null);
        setConfirmData({ date: '', time: '', dentistId: '' });
        fetchAppointments();
      } else {
        toast.error(data.error || 'Failed to confirm appointment');
      }
    } catch (error) {
      console.error('Error confirming appointment:', error);
      toast.error('Failed to confirm appointment');
    }
  };

  const updateAppointmentStatus = async (appointment: Appointment, status: string) => {
    try {
      const response = await fetch(`/api/appointments/${appointment.id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          status,
          authorId: user?.id,
          authorName: user?.name,
          authorRole: user?.role,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success(`Appointment ${status} successfully`);
        fetchAppointments();
      } else {
        toast.error(data.error || `Failed to ${status} appointment`);
      }
    } catch (error) {
      console.error(`Error updating appointment status:`, error);
      toast.error(`Failed to ${status} appointment`);
    }
  };

  const addNote = async () => {
    if (!selectedAppointment || !newNote.trim()) {
      toast.error('Please enter a note');
      return;
    }

    try {
      const response = await fetch(`/api/appointments/${selectedAppointment.id}/notes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: newNote,
          authorId: user?.id,
          authorName: user?.name,
          authorRole: user?.role,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Note added successfully');
        setNoteDialog(false);
        setNewNote('');
        fetchAppointments();
      } else {
        toast.error(data.error || 'Failed to add note');
      }
    } catch (error) {
      console.error('Error adding note:', error);
      toast.error('Failed to add note');
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      pending: 'outline',
      confirmed: 'default',
      completed: 'secondary',
      cancelled: 'destructive'
    };

    return <Badge variant={variants[status] || 'outline'}>{status.toUpperCase()}</Badge>;
  };

  const canConfirm = user?.role === 'staff' || user?.role === 'admin';
  const canManageStatus = user?.role === 'staff' || user?.role === 'admin';
  const canAddNotes = user?.role === 'dentist' || user?.role === 'admin';

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Appointments</h2>
        <Button onClick={fetchAppointments} variant="outline">
          Refresh
        </Button>
      </div>

      <div className="grid gap-4">
        {appointments.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">No appointments found</p>
            </CardContent>
          </Card>
        ) : (
          appointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {appointment.patientName}
                      {getStatusBadge(appointment.status)}
                    </CardTitle>
                    <CardDescription>
                      <div className="space-y-1 mt-2">
                        <div className="flex items-center gap-2">
                          <Mail className="h-3 w-3" />
                          {appointment.patientEmail}
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-3 w-3" />
                          {appointment.patientPhone}
                        </div>
                      </div>
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {canConfirm && appointment.status === 'pending' && (
                      <Dialog open={confirmDialog} onOpenChange={setConfirmDialog}>
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            onClick={() => setSelectedAppointment(appointment)}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Confirm
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Confirm Appointment</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium mb-1">Date</label>
                              <Input
                                type="date"
                                value={confirmData.date}
                                onChange={(e) => setConfirmData(prev => ({ ...prev, date: e.target.value }))}
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Time</label>
                              <Input
                                type="time"
                                value={confirmData.time}
                                onChange={(e) => setConfirmData(prev => ({ ...prev, time: e.target.value }))}
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Dentist</label>
                              <Select
                                value={confirmData.dentistId}
                                onValueChange={(value) => setConfirmData(prev => ({ ...prev, dentistId: value }))}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a dentist" />
                                </SelectTrigger>
                                <SelectContent>
                                  {dentists.map((dentist) => (
                                    <SelectItem key={dentist.id} value={dentist.id}>
                                      {dentist.name} - {dentist.specialization}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            <Button onClick={confirmAppointment} className="w-full">
                              Confirm Appointment
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}

                    {canManageStatus && appointment.status === 'confirmed' && (
                      <>
                        <Button
                          size="sm"
                          onClick={() => updateAppointmentStatus(appointment, 'completed')}
                          variant="outline"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Complete
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => updateAppointmentStatus(appointment, 'cancelled')}
                          variant="outline"
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Cancel
                        </Button>
                      </>
                    )}

                    {canAddNotes && (
                      <Dialog open={noteDialog} onOpenChange={setNoteDialog}>
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedAppointment(appointment)}
                          >
                            <MessageSquare className="h-4 w-4 mr-1" />
                            Add Note
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Add Appointment Note</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <Textarea
                              value={newNote}
                              onChange={(e) => setNewNote(e.target.value)}
                              placeholder="Enter your note..."
                              rows={4}
                            />
                            <Button onClick={addNote} className="w-full">
                              Add Note
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">Reason for Visit:</h4>
                    <p className="text-gray-600">{appointment.reason}</p>
                  </div>

                  {appointment.status === 'confirmed' && appointment.confirmedDate && (
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <CalendarIcon className="h-4 w-4" />
                        {new Date(appointment.confirmedDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {appointment.confirmedTime}
                      </div>
                      {appointment.dentistName && (
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {appointment.dentistName}
                        </div>
                      )}
                    </div>
                  )}

                  {appointment.notes.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Notes:</h4>
                      <div className="space-y-2">
                        {appointment.notes.map((note) => (
                          <div key={note.id} className="bg-gray-50 p-3 rounded">
                            <p className="text-sm">{note.content}</p>
                            <div className="text-xs text-gray-500 mt-1">
                              {note.authorName} ({note.authorRole}) - {new Date(note.createdAt).toLocaleString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}