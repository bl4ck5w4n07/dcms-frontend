'use client';

import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { useAuth } from '../contexts/AuthContext';
import { AlertCircle, Mail, Phone, Timer } from 'lucide-react';

interface OTPVerificationProps {
  email: string;
  phone?: string;
  type: 'signin' | 'signup';
  onSuccess: () => void;
  onBack: () => void;
}

export function OTPVerification({ email, phone, type, onSuccess, onBack }: OTPVerificationProps) {
  const { verifyOTP, resendOTP } = useAuth();
  const [otp, setOTP] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);

  // Determine which contact method to use (prioritize phone over email)
  const contactMethod = phone ? 'phone' : 'email';
  const contactValue = phone || email;
  const contactDisplay = phone ? `${phone.slice(0, 3)}****${phone.slice(-2)}` : `${email.split('@')[0].slice(0, 2)}****@${email.split('@')[1]}`;

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleVerify = async () => {
    if (otp.length !== 6) {
      setError('Please enter a complete 6-digit code');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const result = await verifyOTP(email, otp, type);
      
      if (result.success) {
        onSuccess();
      } else {
        setError(result.error || 'Invalid verification code');
      }
    } catch (error) {
      console.error('OTP verification error:', error);
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    setError('');
    setIsLoading(true);
    setCanResend(false);
    setCountdown(60);

    try {
      const result = await resendOTP(email, type);
      
      if (!result.success) {
        setError(result.error || 'Failed to resend code');
        setCanResend(true);
      }
    } catch (error) {
      console.error('Resend OTP error:', error);
      setError('Network error. Please try again.');
      setCanResend(true);
    } finally {
      setIsLoading(false);
    }

    // Reset countdown
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleOTPChange = (value: string) => {
    setOTP(value);
    // Clear error when user starts typing
    if (error) setError('');
    
    // Auto-verify when 6 digits are entered
    if (value.length === 6) {
      setTimeout(() => handleVerify(), 100);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Verify Your Identity
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            We've sent a 6-digit code to your {contactMethod}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {contactMethod === 'phone' ? <Phone className="h-5 w-5" /> : <Mail className="h-5 w-5" />}
              Enter Verification Code
            </CardTitle>
            <CardDescription>
              Code sent to {contactDisplay}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-4">
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={otp}
                  onChange={handleOTPChange}
                  disabled={isLoading}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <div className="text-center text-sm text-gray-600">
                {canResend ? (
                  <button
                    onClick={handleResend}
                    disabled={isLoading}
                    className="text-blue-600 hover:text-blue-800 font-medium"
                  >
                    Resend Code
                  </button>
                ) : (
                  <span className="flex items-center justify-center gap-1">
                    <Timer className="h-4 w-4" />
                    Resend in {countdown}s
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={handleVerify}
                disabled={isLoading || otp.length !== 6}
                className="w-full"
              >
                {isLoading ? 'Verifying...' : 'Verify Code'}
              </Button>

              <Button 
                variant="outline"
                onClick={onBack}
                disabled={isLoading}
                className="w-full"
              >
                Back to {type === 'signin' ? 'Sign In' : 'Sign Up'}
              </Button>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Didn't receive the code?</h4>
              <ul className="text-xs text-blue-800 space-y-1">
                <li>• Check your spam/junk folder</li>
                <li>• Ensure your {contactMethod} is correct</li>
                <li>• Wait a few minutes for delivery</li>
                <li>• Try resending the code</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}