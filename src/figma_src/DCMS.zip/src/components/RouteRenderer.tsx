import React, { useState } from 'react';
import { Homepage } from './Homepage';
import { Dashboard } from './Dashboard';
import { DashboardLayout } from './DashboardLayout';
import { LoginForm } from './LoginForm';
import { SignUpForm } from './SignUpForm';
import { OTPVerification } from './OTPVerification';
import { ChangePassword } from './ChangePassword';
import { LoadingSpinner } from './LoadingSpinner';
import { useAuth } from '../contexts/AuthContext';
import { Route } from '../hooks/useRouter';

interface RouteRendererProps {
  currentRoute: Route;
  navigate: (route: Route) => void;
}

export function RouteRenderer({ currentRoute, navigate }: RouteRendererProps) {
  const { user } = useAuth();
  
  // Store OTP verification data in component state
  const [otpData, setOtpData] = useState<{
    email: string;
    phone?: string;
    type: 'signin' | 'signup';
  } | null>(null);

  // Auto-redirect authenticated users to dashboard
  if (user && currentRoute !== 'dashboard') {
    navigate('dashboard');
    return <LoadingSpinner />;
  }

  // Auto-redirect non-authenticated users away from dashboard
  if (!user && currentRoute === 'dashboard') {
    navigate('home');
    return <LoadingSpinner />;
  }

  // Render current route
  switch (currentRoute) {
    case 'login':
      return (
        <div className="min-h-screen bg-gray-50">
          <LoginForm 
            onLoginSuccess={() => navigate('dashboard')}
            onOTPRequired={(data) => {
              setOtpData(data);
              navigate('verify-otp');
            }}
          />
        </div>
      );
      
    case 'signup':
      return (
        <div className="min-h-screen bg-gray-50">
          <SignUpForm 
            onSignUpSuccess={() => navigate('dashboard')}
            onOTPRequired={(data) => {
              setOtpData(data);
              navigate('verify-otp');
            }}
          />
        </div>
      );
      
    case 'verify-otp':
      if (!otpData) {
        navigate('login');
        return null;
      }
      return (
        <OTPVerification
          email={otpData.email}
          phone={otpData.phone}
          type={otpData.type}
          onSuccess={() => navigate('dashboard')}
          onBack={() => navigate('login')}
        />
      );
      
    case 'change-password':
      if (!user) {
        navigate('login');
        return null;
      }
      return (
        <ChangePassword
          onSuccess={() => navigate('dashboard')}
          onBack={() => navigate('dashboard')}
        />
      );
      
    case 'dashboard':
      if (!user) {
        navigate('home');
        return null;
      }
      return (
        <DashboardLayout navigate={navigate}>
          <Dashboard navigate={navigate} />
        </DashboardLayout>
      );
      
    case 'home':
    default:
      return (
        <Homepage 
          onLoginClick={() => navigate('login')}
          onSignUpClick={() => navigate('signup')}
          onBookingSuccess={() => {
            // If user becomes authenticated after booking, go to dashboard
            if (user) {
              navigate('dashboard');
            }
          }}
        />
      );
  }
}