// This component has been replaced by the patient detail page
// at /app/dashboard/patients/[id]/page.tsx
//
// This file is kept for reference but is no longer used in the application.
// The functionality has been moved to a dedicated Next.js page route for better UX.

export function PatientDetailView() {
  return null;
}