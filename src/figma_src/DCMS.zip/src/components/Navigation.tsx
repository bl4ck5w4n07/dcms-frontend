'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from './ui/button';
import { useAuth } from '../contexts/AuthContext';
import { 
  Calendar,
  Users,
  FileText,
  PlusCircle,
  LogOut,
  Home,
  UserPlus,
  User,
  Shield,
  Lock
} from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  onChangePassword?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeSection, setActiveSection, onChangePassword }) => {
  const { user, signOut } = useAuth();
  const router = useRouter();

  const handleChangePassword = () => {
    if (onChangePassword) {
      onChangePassword();
    } else {
      router.push('/change-password');
    }
  };

  const handleSignOut = async () => {
    await signOut();
    router.push('/');
  };

  // Define menu items based on user role
  const getMenuItems = () => {
    if (!user) return [];

    const baseItems = [
      { id: 'dashboard', label: 'Dashboard', icon: Home }
    ];

    switch (user.role) {
      case 'patient':
        return [
          ...baseItems,
          { id: 'appointments', label: 'My Appointments', icon: Calendar },
          { id: 'profile', label: 'My Profile', icon: User }
        ];
        
      case 'dentist':
        return [
          ...baseItems,
          { id: 'appointments', label: 'Appointments', icon: Calendar },
          { id: 'patients', label: 'Patients', icon: Users },
          { id: 'profile', label: 'My Profile', icon: User }
        ];
        
      case 'admin':
        return [
          ...baseItems,
          { id: 'appointments', label: 'Appointments', icon: Calendar },
          { id: 'patients', label: 'Patients', icon: Users },
          { id: 'walk-in-patient', label: 'Walk-in Patients', icon: UserPlus },
          { id: 'admin/users', label: 'User Management', icon: Shield },
          { id: 'profile', label: 'My Profile', icon: User }
        ];
        
      default: // staff
        return [
          ...baseItems,
          { id: 'appointments', label: 'Appointments', icon: Calendar },
          { id: 'patients', label: 'Patients', icon: Users },
          { id: 'walk-in-patient', label: 'Walk-in Patients', icon: UserPlus },
          { id: 'profile', label: 'My Profile', icon: User }
        ];
    }
  };

  const menuItems = getMenuItems();

  return (
    <div className="w-64 bg-white shadow-lg h-screen flex flex-col">
      <div className="p-6 border-b">
        <h1 className="text-xl font-semibold text-gray-800">
          {user?.role === 'patient' ? 'Patient Portal' : 'Dental Clinic'}
        </h1>
        <p className="text-sm text-gray-600 mt-1">Welcome, {user?.name}</p>
        <p className="text-xs text-gray-500 capitalize">
          {user?.role === 'admin' ? 'Dentist (Admin)' : user?.role}
        </p>
      </div>
      
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeSection === item.id ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveSection(item.id)}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.label}
              </Button>
            );
          })}
        </div>
      </nav>
      
      <div className="p-4 border-t space-y-2">
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={handleChangePassword}
        >
          <Lock className="mr-3 h-4 w-4" />
          Change Password
        </Button>
        
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={handleSignOut}
        >
          <LogOut className="mr-3 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};