'use client';

import { BookAppointment } from '../../../components/BookAppointment';

export default function BookAppointmentPage() {
  return <BookAppointment />;
}