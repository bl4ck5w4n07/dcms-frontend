
  # DCMS

  This is a code bundle for DCMS. The original project is available at https://www.figma.com/design/RTLbE4dIeVDG7VWMY5sKT0/DCMS.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  