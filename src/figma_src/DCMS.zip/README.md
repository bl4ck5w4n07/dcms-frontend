
  # DCMS

  This is a code bundle for DCMS. The original project is available at https://www.figma.com/design/2SvHpaEamN1ov2pTj0po4I/DCMS.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  